tinyMCE.addI18n('hu.ddcode',{
	desc 	: 'Syntax Highlighter',
	select 	: 'Select Code Type:'
});
