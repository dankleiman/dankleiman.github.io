tinyMCE.addI18n('pt.spoiler',{
	desc : 'Spoiler'
});
