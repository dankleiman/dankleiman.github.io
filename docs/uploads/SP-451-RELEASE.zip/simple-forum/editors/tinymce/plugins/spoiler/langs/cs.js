tinyMCE.addI18n('cs.spoiler',{
	desc : 'Spoiler'
});
