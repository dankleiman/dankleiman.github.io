tinyMCE.addI18n('pl.spoiler',{
	desc : 'Spoiler'
});
