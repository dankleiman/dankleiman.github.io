tinyMCE.addI18n('et.spoiler',{
	desc : 'Spoiler'
});
