tinyMCE.addI18n('no.spoiler',{
	desc : 'Spoiler'
});
