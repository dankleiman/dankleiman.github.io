tinyMCE.addI18n('vi.spoiler',{
	desc : 'Spoiler'
});
