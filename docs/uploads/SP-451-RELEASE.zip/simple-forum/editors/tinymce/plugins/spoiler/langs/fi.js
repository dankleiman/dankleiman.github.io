tinyMCE.addI18n('fi.spoiler',{
	desc : 'Spoiler'
});
