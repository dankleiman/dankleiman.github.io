tinyMCE.addI18n('ru.spoiler',{
	desc : 'Spoiler'
});
