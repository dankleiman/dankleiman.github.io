tinyMCE.addI18n('da.spoiler',{
	desc : 'Spoiler'
});
