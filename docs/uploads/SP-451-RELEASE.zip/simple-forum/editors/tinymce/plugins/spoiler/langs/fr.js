tinyMCE.addI18n('fr.spoiler',{
	desc : 'Spoiler'
});
