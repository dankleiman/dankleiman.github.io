tinyMCE.addI18n('bs.spoiler',{
	desc : 'Spoiler'
});
