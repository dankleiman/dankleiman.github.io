tinyMCE.addI18n('sv.spoiler',{
	desc : 'Spoiler'
});
