tinyMCE.addI18n('lt.spoiler',{
	desc : 'Spoiler'
});
