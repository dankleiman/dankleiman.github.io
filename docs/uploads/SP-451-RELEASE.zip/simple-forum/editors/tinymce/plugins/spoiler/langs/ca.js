tinyMCE.addI18n('ca.spoiler',{
	desc : 'Spoiler'
});
