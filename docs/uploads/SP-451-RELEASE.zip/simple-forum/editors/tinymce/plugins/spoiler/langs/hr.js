tinyMCE.addI18n('hr.spoiler',{
	desc : 'Spoiler'
});
