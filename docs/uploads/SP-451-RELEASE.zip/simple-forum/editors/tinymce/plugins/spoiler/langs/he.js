tinyMCE.addI18n('he.spoiler',{
	desc : 'Spoiler'
});
