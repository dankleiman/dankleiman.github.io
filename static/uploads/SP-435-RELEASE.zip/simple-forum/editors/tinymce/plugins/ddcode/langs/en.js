tinyMCE.addI18n('en.ddcode',{
	desc : 'Highlight your code'
});
