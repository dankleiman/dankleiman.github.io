tinyMCE.addI18n('lv.paste_dlg',{
text_title:"Izmantojiet CTRL+V uz j\u016Bsu tastat\u016Bras lai iekop\u0113t tekstu log\u0101.",
text_linebreaks:"Sagl\u0101b\u0101t l\u012Bniju sadal\u012Bt\u0101jus",
word_title:"Izmantojiet CTRL+V uz j\u016Bsu tastat\u016Bras lai iekop\u0113t tekstu log\u0101."
});