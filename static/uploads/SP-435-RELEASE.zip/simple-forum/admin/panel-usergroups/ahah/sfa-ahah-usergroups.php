<?php
/*
Simple:Press
User Group Specials
$LastChangedDate: 2010-04-18 17:22:20 +0100 (Sun, 18 Apr 2010) $
$Rev: 3920 $
*/

if (preg_match('#' . basename(__FILE__) . '#', $_SERVER['PHP_SELF']))
{
	die('Access Denied');
}

sfa_admin_ahah_support();

global $wpdb;

# Check Whether User Can Manage User Groups
if (!sfc_current_user_can('SPF Manage User Groups'))
{
	echo (__('Access Denied', "sforum"));
	die();
}

if (isset($_GET['ug']))
{
	$usergroup_id = sf_esc_int($_GET['ug']);
	$sql = "SELECT ".SFMEMBERSHIPS.".user_id, display_name
			FROM ".SFMEMBERSHIPS."
			JOIN ".SFMEMBERS." ON ".SFMEMBERS.".user_id = ".SFMEMBERSHIPS.".user_id
			WHERE ".SFMEMBERSHIPS.".usergroup_id=".$usergroup_id."
			ORDER BY display_name";
	$members = $wpdb->get_results($sql);
	echo sfa_display_member_roll($members);
	die();
}

function sfa_display_member_roll($members)
{
	$out = '';
	$out.= '<fieldset class="sfsubfieldset">';
    $out.= '<legend>'.__("User Group Members", "sforum").'</legend>';
	if ($members)
	{
		$out.= '<ul class="memberlist">';
		for ($x=0; $x<count($members); $x++)
		{
			$out.= '<li>'.sf_filter_name_display($members[$x]->display_name).'</li>';
		}
		$out.= '</ul>';
	} else {
		$out.= __("No Members in this User Group.", "sforum");
	}
    $out.= '</fieldset>';

	return $out;
}

?>